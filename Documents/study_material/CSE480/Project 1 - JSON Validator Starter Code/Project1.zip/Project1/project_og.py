import json


class NotValidError(Exception):
    pass


class NotWellFormedError(Exception):
    pass


class Validator(object):
    def __init__(self, schema=None):
        try:
            self.schema = json.loads(schema)
        except json.JSONDecodeError:
            raise NotWellFormedError
        self.types = {"object", "null", "boolean", "array", "number", "integer", "string"}
        self.not_valid_error = NotValidError()
        self.not_wf_error = NotWellFormedError()

    def validate(self, data):
        def type_validate(given_data, schema):
            elem_type = schema["type"]
            for elem in given_data:
                if elem_type == "boolean" and type(elem) != bool:
                    raise self.not_valid_error
                if elem_type == "string" and type(elem) != str:
                    raise self.not_valid_error
                if elem_type == "integer" and type(elem) != int:
                    raise self.not_valid_error
                if elem_type == "array" and type(elem) != list:
                    raise self.not_valid_error
                if elem_type == "number" and (type(elem) != float or type(elem) != int):
                    raise self.not_valid_error
                if elem_type == "object" and type(elem) != dict:
                    raise self.not_valid_error
                if elem_type == "null" and elem is not None:
                    raise self.not_valid_error
            return True

        def int_validate(given_data):
            if type(given_data) == int:
                return True
            else:
                raise self.not_valid_error

        def list_validate(given_data, schema):
            def ascending_check(lst):
                if len(lst) <= 1:
                    return True
                prev = lst[0]
                for i in range(1,len(given_data)):
                    if lst[i] > prev or lst[i] == prev:
                        prev = lst[i]
                    else:
                        return False
                return True

            def unique_check(lst):
                cache = {}
                for i in lst:
                    if i in cache:
                        cache[i] += 1
                    else:
                        cache[i] = 1
                for elem in cache.values():
                    if elem != 1:
                        return False
                return True

            def spartan_check(lst):
                possibilities = {"green", "white"}
                if len(lst) <= 0:
                    return True
                for elem in lst:
                    if elem not in possibilities:
                        return False
                return True

            def element_check(elem_data):
                elem_type = elem_schema['type']
                if elem_type not in self.types:
                    raise self.not_wf_error
                return type_validate(elem_data, elem_schema)

            if type(given_data) == list:
                if "qualities" in schema:
                    qualities = schema["qualities"]
                    if len(qualities) > 0:
                        for i in range(len(qualities)):
                            if qualities[i] == "ascending" and not ascending_check(given_data):
                                raise self.not_valid_error
                            if qualities[i] == "unique" and not unique_check(given_data):
                                raise self.not_valid_error
                            if qualities[i] == "nonempty" and len(given_data) <= 0:
                                raise self.not_valid_error
                            if qualities[i] == "spartan" and not spartan_check(given_data):
                                raise self.not_valid_error
                if "element" in schema:
                    elem_schema = json.loads(json.dumps(schema['element']))
                    if element_check(given_data):
                        for elem in given_data:
                            if type(elem) == list:
                                list_validate(decoder.decode(json.dumps(elem)), elem_schema)
                return True
            else:
                raise self.not_valid_error

        def obj_validate(given_data, schema):
            def obj_field_check(data, obj_schema):
                if len(data.keys()) < len(obj_schema["fields"]):
                    raise self.not_valid_error
                for field in obj_schema["fields"]:
                    if field not in data:
                        raise self.not_valid_error
                return True

            schema_cache = {}
            if len(given_data) == 0 and "fields" in schema:
                raise self.not_valid_error
            if "fields" in schema:
                obj_field_check(given_data, schema)
            if "fields_qualities" in schema:
                if len(schema["fields_qualities"]) > 0 and len(given_data) == 0:
                    raise self.not_valid_error
                for qual in schema["fields_qualities"]:
                    if qual not in given_data:
                        raise self.not_valid_error
                    schema_cache[qual] = json.loads(json.dumps(schema["fields_qualities"][qual]))
            for obj_data in given_data:
                if obj_data in schema_cache:
                    data_type = schema_cache[obj_data]["type"]
                    if type_validate(obj_data, schema_cache[obj_data]):
                        if data_type == "string" and type(given_data[obj_data]) != str:
                            raise self.not_valid_error
                        if data_type == "integer" and type(given_data[obj_data]) != int:
                            raise self.not_valid_error
                        if data_type == "array" and not list_validate(given_data[obj_data], schema_cache[obj_data]):
                            raise self.not_valid_error
                        if data_type == "object" and not obj_validate(given_data[obj_data], schema_cache[obj_data]):
                            raise self.not_valid_error
            return True

        decoder = json.JSONDecoder()

        if self.schema == {}:
            try:
                decoder.decode(data)
            except json.JSONDecodeError:
                raise self.not_wf_error

        elif self.schema["type"] in self.types:
            if self.schema["type"] == "integer":
                try:
                    int_validate(decoder.decode(data))
                except json.JSONDecodeError:
                    raise self.not_wf_error
            elif self.schema["type"] == "array":
                try:
                    list_validate(decoder.decode(data), self.schema)
                except json.JSONDecodeError:
                    raise self.not_wf_error
            elif self.schema["type"] == "object":
                try:
                    obj_validate(decoder.decode(data), self.schema)
                except json.JSONDecodeError:
                    raise self.not_wf_error


def build_validator(schema_string):
    new_validator = Validator(schema_string)
    return new_validator
